package ch.fhnw.ima.intro;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CalculatorTest {

    @Test
    public void add() {
        assertEquals("Simple addition", 6, Calculator.add(5, 1));
        assertEquals("Adding neutral element", 99, Calculator.add(99, 0));
        assertEquals("Adding negative numbers", -7, Calculator.add(-5, -2));
    }

    @Test
    public void subtract() {
        assertEquals("Simple subtraction", 4, Calculator.subtract(5, 1));
        assertEquals("Subtracting neutral element", 99, Calculator.subtract(99, 0));
        assertEquals("Subtracting negative numbers", -3, Calculator.subtract(-5, -2));
    }

}