package ch.fhnw.ima.intro;

public final class Calculator {

    public static int add(int a, int b) {
        throw new UnsupportedOperationException();
        // TODO Delete line above and `return` correct result
    }

    public static int subtract(int a, int b) {
        throw new UnsupportedOperationException();
        // TODO Delete line above and `return` correct result
    }

}