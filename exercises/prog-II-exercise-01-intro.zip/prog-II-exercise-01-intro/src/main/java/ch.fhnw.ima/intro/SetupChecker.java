package ch.fhnw.ima.intro;

import java.util.function.Supplier;

public class SetupChecker {

    public static void main(String[] args) {
        // This lambda expression will only compile with Java 8
        Supplier<String> helloWorldSupplier = () -> "Hello World";
        System.out.println(helloWorldSupplier.get());
    }

}
