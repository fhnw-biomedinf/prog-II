package ch.fhnw.ima;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Map;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Map101Test {

    @Test
    public void createHelloWorldMap() {
        Map<String, String> map = Map101.createHelloWorldMap();
        assertNotNull(map);
        assertEquals("Map size", 1, map.size());
        assertTrue("Contains a 'hello' key", map.containsKey("hello"));
        assertEquals("Key 'hello' mapped to 'world'", "world", map.get("hello"));
    }

    @Test
    public void countCharactersEmpty() {
        assertTrue("Empty map for empty input", Map101.countCharacters("").isEmpty());
    }

    @Test
    public void countCharacters() {
        Map<Character, Integer> counts = Map101.countCharacters("hello world");
        assertHelloWorld(counts);
    }

    @Test
    public void countCharactersCaseInsensitive() {
        Map<Character, Integer> counts = Map101.countCharacters("HeLLo WORlD");
        assertHelloWorld(counts);
    }

    @Test
    public void countCharactersWhitespace() {
        Map<Character, Integer> counts = Map101.countCharacters("   *   ");
        assertEquals(2, counts.size());
        assertTrue("Occurrence of space character", counts.containsKey(' '));
        assertEquals("Number of occurrences of space character", 6, counts.get(' ').intValue());
        assertTrue("Occurrence of '*' character", counts.containsKey('*'));
        assertEquals("Number of occurrences of '*' character", 1, counts.get('*').intValue());
    }

    private static void assertHelloWorld(Map<Character, Integer> counts) {
        assertEquals(8, counts.size());
        assertTrue("Occurrence of 'l' character", counts.containsKey('l'));
        assertEquals("Number of occurrences of 'l' character", 3, counts.get('l').intValue());
        assertFalse("No occurrences of 'x' character", counts.containsKey('x'));
    }

}