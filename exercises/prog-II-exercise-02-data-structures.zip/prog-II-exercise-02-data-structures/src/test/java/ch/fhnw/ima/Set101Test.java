package ch.fhnw.ima;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.*;
import java.util.function.BiFunction;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Set101Test {

    private static final List<String> WORDS = Arrays.asList("one", "two", "one", "three", "three", "four");

    @Test
    public void createHelloWorldSet() {
        Set<String> set = Set101.createHelloWorldSet();
        assertNotNull(set);
        assertEquals("Set size", 2, set.size());
        assertTrue("Contains 'hello' element", set.contains("hello"));
        assertTrue("Contains 'world' element", set.contains("world"));
    }

    @Test
    public void filterByPrefixEmpty() {
        testFilterByPrefixEmpty(Set101::filterByPrefix);
    }

    @Test
    public void filterByPrefixEmptyStreamBased() {
        testFilterByPrefixEmpty(Set101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixMultipleMatches() {
        testFilterByPrefixMultipleMatches(Set101::filterByPrefix);
    }

    @Test
    public void filterByPrefixMultipleMatchesStreamBased() {
        testFilterByPrefixMultipleMatches(Set101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixSingleMatch() {
        testFilterByPrefixSingleMatch(Set101::filterByPrefix);
    }

    @Test
    public void filterByPrefixSingleMatchStreamBased() {
        testFilterByPrefixSingleMatch(Set101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixNoMatch() {
        testFilterByPrefixNoMatch(Set101::filterByPrefix);
    }

    @Test
    public void filterByPrefixNoMatchStreamBased() {
        testFilterByPrefixNoMatch(Set101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixAllMatch() {
        testFilterByPrefixAllMatch(Set101::filterByPrefix);
    }

    @Test
    public void filterByPrefixAllMatchStreamBased() {
        testFilterByPrefixAllMatch(Set101::filterByPrefixStreamBased);
    }

    //------------------------------------------------------------------------------------
    // Methods below test all filter logic, abstracting calls to concrete filter-function
    //------------------------------------------------------------------------------------

    private static void testFilterByPrefixEmpty(BiFunction<List<String>, String, Set<String>> filterFunction) {
        assertTrue("Filtering empty list", filterFunction.apply(Collections.emptyList(), "").isEmpty());
    }

    private static void testFilterByPrefixMultipleMatches(BiFunction<List<String>, String, Set<String>> filterFunction) {
        Set<String> tWords = filterFunction.apply(WORDS, "t");
        assertEquals("Unique words starting with 't'", of("two", "three"), tWords);
    }

    private static void testFilterByPrefixSingleMatch(BiFunction<List<String>, String, Set<String>> filterFunction) {
        {
            Set<String> thWords = filterFunction.apply(WORDS, "th");
            assertEquals("Only one unique word starting with 'th'", of("three"), thWords);
        }
        {
            Set<String> four = filterFunction.apply(WORDS, "four");
            assertEquals("Only one word starting with 'four'", of("four"), four);
        }
    }

    private static void testFilterByPrefixNoMatch(BiFunction<List<String>, String, Set<String>> filterFunction) {
        assertTrue("No banana-words", filterFunction.apply(WORDS, "banana").isEmpty());
    }

    private static void testFilterByPrefixAllMatch(BiFunction<List<String>, String, Set<String>> filterFunction) {
        List<String> expectedUniqueOrderedWords = new ArrayList<>(new LinkedHashSet<>(WORDS));
        List<String> actualUniqueOrderedWords = new ArrayList<>(filterFunction.apply(WORDS, ""));
        String message = "All words match empty prefix (unique, in order)";
        assertEquals(message, expectedUniqueOrderedWords, actualUniqueOrderedWords);
    }

    @SafeVarargs
    private static <E> Set<E> of(E... elements) {
        return new LinkedHashSet<>(Arrays.asList(elements));
    }

}