package ch.fhnw.ima;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.BiFunction;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class List101Test {

    private static final List<String> WORDS = Arrays.asList("one", "two", "three", "four", "five", "six", "seven");

    @Test
    public void createHelloWorldList() {
        List<String> list = List101.createHelloWorldList();
        assertNotNull(list);
        assertEquals("List size", 2, list.size());
        assertEquals("First element", "hello", list.get(0));
        assertEquals("Second element", "world", list.get(1));
    }

    @Test
    public void createListEmpty() {
        List<String> list = List101.createList();
        assertNotNull(list);
        assertTrue("List should be empty", list.isEmpty());
    }

    @Test
    public void createList() {
        List<String> list = List101.createList("apple", "orange", "banana");
        assertNotNull(list);
        assertEquals("List size", 3, list.size());
        assertEquals("Second element", "orange", list.get(1));
    }

    @Test
    public void createSquareCalculations() {
        List<Integer> numbers = Arrays.asList(2, 5, 10, -1);
        List<String> calculations = List101.createSquareCalculations(numbers);
        assertEquals("Number of calculations", numbers.size(), calculations.size());
        assertEquals("Squaring 10", "10 x 10 = 100", calculations.get(2));
        assertEquals("Squaring -1", "-1 x -1 = 1", calculations.get(3));
    }

    @Test
    public void filterByPrefixEmpty() {
        testFilterByPrefixEmpty(List101::filterByPrefix);
    }

    @Test
    public void filterByPrefixEmptyStreamBased() {
        testFilterByPrefixEmpty(List101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixMultipleMatches() {
        testFilterByPrefixMultipleMatches(List101::filterByPrefix);
    }

    @Test
    public void filterByPrefixMultipleMatchesStreamBased() {
        testFilterByPrefixMultipleMatches(List101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixSingleMatch() {
        testFilterByPrefixSingleMatch(List101::filterByPrefix);
    }

    @Test
    public void filterByPrefixSingleMatchStreamBased() {
        testFilterByPrefixSingleMatch(List101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixNoMatch() {
        testFilterByPrefixNoMatch(List101::filterByPrefix);
    }

    @Test
    public void filterByPrefixNoMatchStreamBased() {
        testFilterByPrefixNoMatch(List101::filterByPrefixStreamBased);
    }

    @Test
    public void filterByPrefixAllMatch() {
        testFilterByPrefixAllMatch(List101::filterByPrefix);
    }

    @Test
    public void filterByPrefixAllMatchStreamBased() {
        testFilterByPrefixAllMatch(List101::filterByPrefixStreamBased);
    }

    //------------------------------------------------------------------------------------
    // Methods below test all filter logic, abstracting calls to concrete filter-function
    //------------------------------------------------------------------------------------

    private static void testFilterByPrefixEmpty(BiFunction<List<String>, String, List<String>> filterFunction) {
        assertTrue("Filtering empty list", filterFunction.apply(Collections.emptyList(), "").isEmpty());
    }

    private static void testFilterByPrefixMultipleMatches(BiFunction<List<String>, String, List<String>> filterFunction) {
        List<String> tWords = filterFunction.apply(WORDS, "t");
        assertEquals("Words starting with 't'", Arrays.asList("two", "three"), tWords);
    }

    private static void testFilterByPrefixSingleMatch(BiFunction<List<String>, String, List<String>> filterFunction) {
        {
            List<String> thWords = filterFunction.apply(WORDS, "th");
            assertEquals("Only one word starting with 'th'", Collections.singletonList("three"), thWords);
        }
        {
            List<String> four = filterFunction.apply(WORDS, "four");
            assertEquals("Only one word starting with 'four'", Collections.singletonList("four"), four);
        }
    }

    private static void testFilterByPrefixNoMatch(BiFunction<List<String>, String, List<String>> filterFunction) {
        assertTrue("No banana-words", filterFunction.apply(WORDS, "banana").isEmpty());
    }

    private static void testFilterByPrefixAllMatch(BiFunction<List<String>, String, List<String>> filterFunction) {
        assertEquals("All words match empty prefix", WORDS, filterFunction.apply(WORDS, ""));
    }

}