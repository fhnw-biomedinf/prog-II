package ch.fhnw.ima;

import java.util.List;

/**
 * An introductory warm-up to working with {@link java.util.List}s.
 *
 * @author Rahel Lüthy
 */
public final class List101 {

    /**
     * Creates a list with exactly two elements, "hello" and "world".
     *
     * @return the created list
     */
    public static List<String> createHelloWorldList() {
        throw new UnsupportedOperationException();
    }

    /**
     * Creates a list with the given elements.
     *
     * @param elements to be included in the list
     * @return the created list
     */
    public static List<String> createList(String... elements) {
        throw new UnsupportedOperationException();
    }

    /**
     * Illustrates how numbers can be squared. For each given number, an
     * example calculation is created: An input number of 3 should e.g. produce the
     * string "3 x 3 = 9".
     *
     * @param numbers all input numbers for which to produce example calculations
     * @return the created example calculations
     */
    public static List<String> createSquareCalculations(List<Integer> numbers) {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns a list which only contains the words which starts with the given prefix.
     *
     * @param words  to be filtered
     * @param prefix to match against
     * @return the filtered list
     */
    public static List<String> filterByPrefix(List<String> words, String prefix) {
        // Use startsWith(prefix) from the String class to check for matches
        throw new UnsupportedOperationException();
    }

    /**
     * Optional: Try implementing the same filter logic by using Java 8 streams (as covered in
     * 'The Java 8 Stream API' section of the course documentation).
     */
    public static List<String> filterByPrefixStreamBased(List<String> words, String prefix) {
        throw new UnsupportedOperationException();
    }

}