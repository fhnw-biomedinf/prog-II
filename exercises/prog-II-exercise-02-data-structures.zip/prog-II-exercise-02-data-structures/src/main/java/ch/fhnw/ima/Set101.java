package ch.fhnw.ima;

import java.util.List;
import java.util.Set;

/**
 * An introductory warm-up to working with {@link java.util.Set}s.
 *
 * @author Rahel Lüthy
 */
public final class Set101 {

    /**
     * Creates a set with exactly two elements, "hello" and "world".
     *
     * @return the created set
     */
    public static Set<String> createHelloWorldSet() {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns all *unique* words which start with the given prefix (in the same order in which
     * they appear in the input list).
     *
     * @param words  an input list to be filtered
     * @param prefix to match against
     * @return the unique, filtered words (in order of appearance)
     */
    public static Set<String> filterByPrefix(List<String> words, String prefix) {
        throw new UnsupportedOperationException();
    }

    /**
     * Optional: Try implementing the same filter logic by using Java 8 streams  (as covered in
     * 'The Java 8 Stream API' section of the course documentation).
     */
    public static Set<String> filterByPrefixStreamBased(List<String> words, String prefix) {
        throw new UnsupportedOperationException();
    }

}