package ch.fhnw.ima;

import java.util.Map;

/**
 * An introductory warm-up to working with {@link java.util.Map}s.
 *
 * @author Rahel Lüthy
 */
public final class Map101 {

    /**
     * Creates a map with exactly one entry: A key "hello" that maps to
     * the value "world".
     *
     * @return the created map
     */
    public static Map<String, String> createHelloWorldMap() {
        throw new UnsupportedOperationException();
    }

    /**
     * Counts case-insensitive character occurrences in a given text. For example, the text
     * "HeLLo WORlD" should lead to the following mappings:
     * <p>
     * 'h' -> 1
     * 'e' -> 1
     * 'l' -> 3
     * 'o' -> 2
     * ' ' -> 1 (space character)
     * 'w' -> 1
     * 'r' -> 1
     * 'd' -> 1
     *
     * @param input to be processed
     * @return the character counts
     */
    public static Map<Character, Integer> countCharacters(String input) {
        // Hint: Use input.toLowerCase().toCharArray()
        throw new UnsupportedOperationException();
    }

}
