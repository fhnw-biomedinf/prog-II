package ch.fhnw.ima;

import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import static org.junit.Assert.*;

public class SpellCheckerTest {

    private File dictionaryFile;

    @Before
    public void before() throws URISyntaxException {
        this.dictionaryFile = new File(SpellChecker.class.getResource("/words.txt").toURI());
    }

    @Test
    public void parseDictionary() throws IOException {
        Set<String> dictionary = SpellChecker.parseDictionary(dictionaryFile);
        assertEquals(235886, dictionary.size());
        assertTrue(dictionary.contains("program"));
        assertFalse(dictionary.contains("unknown-gibberish"));
    }

    @Test
    public void checkSpellingWithCustomDictionary() {
        Set<String> customDictionary = setOf("one", "two", "three");
        assertTrue(SpellChecker.checkSpelling("three one one one two", customDictionary).isEmpty());
        assertEquals(setOf("unknown", "words"), SpellChecker.checkSpelling("two unknown words", customDictionary));
    }

    @Test
    public void checkSpellingWithDictionaryFromFile() throws IOException {
        Set<String> dictionary = SpellChecker.parseDictionary(dictionaryFile);
        assertTrue(SpellChecker.checkSpelling("three one one one two", dictionary).isEmpty());
        assertTrue(SpellChecker.checkSpelling("unknown is a known word", dictionary).isEmpty());
        String input = "a known word and some unknown-gibberish plus blabla";
        assertEquals(setOf("unknown-gibberish", "blabla"), SpellChecker.checkSpelling(input, dictionary));
    }

    // A simple helper method for easy set creation
    private static Set<String> setOf(String... strings) {
        return new LinkedHashSet<>(Arrays.asList(strings));
    }

}