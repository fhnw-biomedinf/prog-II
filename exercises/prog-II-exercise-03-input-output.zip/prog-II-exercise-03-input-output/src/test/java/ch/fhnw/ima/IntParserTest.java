package ch.fhnw.ima;

import org.junit.Test;

import static org.junit.Assert.*;

public class IntParserTest {

    @Test
    public void parseSumEmpty() {
        assertEquals(0, IntParser.parseSum(""));
    }

    @Test
    public void parseSum() {
        assertEquals(6, IntParser.parseSum("1,2,3"));
    }

    @Test
    public void parseSumMultiline() {
        assertEquals(45, IntParser.parseSum("1,2,3\n4,5,6\n7,8,9"));
    }

}