package ch.fhnw.ima;

import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class LineNumberPrependerTest {

    private static final String EXPECTED_OUTPUT =
            "/* 1 */ Mary had a little lamb,\n" +
            "/* 2 */ His fleece was white as snow,\n" +
            "/* 3 */ And everywhere that Mary went,\n" +
            "/* 4 */ The lamb was sure to go.\n";

    @Test
    public void prependNumberToSingleLine() {
        assertEquals("/* 3 */ a test line", LineNumberPrepender.prependNumberToSingleLine(3, "a test line"));
    }

    @Test
    public void prependNumbersToAllLines() throws IOException {
        File inputFile = new File(LineNumberPrependerTest.class.getResource("/mary.txt").getPath());
        String actualOutput = LineNumberPrepender.prependNumbersToAllLines(inputFile);
        assertEquals(EXPECTED_OUTPUT, actualOutput);
    }

}