package ch.fhnw.ima;

import java.io.File;
import java.io.IOException;
import java.util.Set;

/**
 * Checks the spelling of words in a file.
 *
 * @author Rahel Lüthy
 */
public final class SpellChecker {

    /**
     * Reads a set of all known words from the given dictionary file.
     *
     * @param dictionaryFile a file containing known words (one per line)
     * @return the parsed dictionaryFile.
     */
    public static Set<String> parseDictionary(File dictionaryFile) throws IOException {
        // Use a Scanner to read from dictionaryFile
        throw new UnsupportedOperationException();
    }

    /**
     * Checks the spelling of all words in the given input string by using the given
     * dictionary of known words.
     *
     * @param input      to be spell-checked.
     * @param dictionary the set of known words (i.e. expected spelling).
     * @return all words which are not spelled correctly (in order of appearance).
     */
    public static Set<String> checkSpelling(String input, Set<String> dictionary) {
        // Use a LinkedHashSet to collect unknown words in order of appearance
        throw new UnsupportedOperationException();
    }

}
