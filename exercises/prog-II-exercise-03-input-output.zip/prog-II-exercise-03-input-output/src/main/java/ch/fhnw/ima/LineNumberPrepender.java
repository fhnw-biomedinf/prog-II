package ch.fhnw.ima;

import java.io.File;
import java.io.IOException;

/**
 * Prepends a number-prefix to text lines.
 *
 * @author Rahel Lüthy
 */
public final class LineNumberPrepender {

    /**
     * Prepends a number-prefix to the given line.
     *
     * @param lineNumber the number to be used in the prefix.
     * @param line       the line to be prefixed.
     * @return the prefixed output.
     */
    public static String prependNumberToSingleLine(int lineNumber, String line) {
        // Try using String.format when implementing this method
        throw new UnsupportedOperationException();
    }

    /**
     * Prepends a line-number-prefix to all lines of the given file.
     *
     * @param inputFile the file to read line-by-line.
     * @return the prefixed output.
     */
    public static String prependNumbersToAllLines(File inputFile) throws IOException {
        // Use a Scanner to read from inputFile
        // Use `prependLineNumberToSingleLine` to prefix individual lines
        // Use a StringBuilder to accumulate the final output
        throw new UnsupportedOperationException();
    }

}
