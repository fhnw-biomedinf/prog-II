package ch.fhnw.ima;

/**
 * Parses integer numbers.
 *
 * @author Rahel Lüthy
 */
public final class IntParser {

    /**
     * Parses comma-separated integer numbers from the given input and calculates
     * the sum of all values.
     *
     * @param input to be parsed.
     * @return the sum of all parsed values.
     */
    public static int parseSum(String input) {
        throw new UnsupportedOperationException();
    }

}