# Introduction

This set of exercises is inspired by http://agar.io, a simple game where a player controls a cell
on screen. The goal of the game is to gain as much mass as possible by swallowing smaller cells without being
swallowed by bigger ones. If you don't know the game, you might want to give agar.io a spin via "Play as guest"!

Unfortunately, we will not have the time to implement a massive multi-player online game. Instead, we will aim at a
simpler, yet playable variant. You will gradually implement the game's data structures based on object-oriented
principles. Your data structures are embedded in a provided application, which you can just run (you don't need to
implement any graphical components yourself). The applications will only work if your data structures behave
like they are supposed to – as usual, tests are here to assert just that.

# Part 1: Simple Cell

In a first increment, you are asked to implement `SimpleCell` and `SimpleCellFactory`. Let your implementation
be driven by the provided JUnit tests and the comments in the code.

Once all the tests are green, you can run `SimpleCellApp`. This application uses your implementations to display cells
on screen. As you will see, the cells are still very basic, but you can already change their size with the provided
buttons!

You will learn:
- How to implement multiple constructors
- How to implement methods which access fields
- How to implement methods which mutate fields
- How to use the enum type
- How object-oriented principles allow to compose simple applications

# Part 2: Moving Agar Cell

In a second increment, you are asked to implement an agar cell, as defined by the `AgarCell` interface.
When used inside the `AgarCellApp`, this cell moves towards the mouse pointer at a constant speed, i.e. it can be
directed via mouse interaction. The cell gains in mass by eating food (other cells). Its speed is dependent on its
mass, i.e. it moves fast while small, but becomes slower as it grows.

The `MovingAgarCell` class provides a stub for you to get started. Make it implement the `AgarCell` interface (HINT: Try
re-using `SimpleCell`). Adjust `AgarCellFactory` to create a `MovingAgarCell` (getting rid of the current
`DummyAgarCell` implementation). As usual, you are done once all tests in `AgarCellTest` pass.

From an OOP perspective, a `MovingAgarCell` is a `SimpleCell` with additional capabilities: It has a current position,
a target position (the mouse coordinates), and a speed. It uses the `CellPhysics` helper class to update its current
position. Its speed field gets updated whenever the cell's mass changes. The actual speed calculation is again delegated
to the `CellPhysics` class.

You will learn:
- How to implement an existing interface (`AgarCell`)
- How to extend an existing base class (`SimpleCell`)
- How to use existing helper classes via composition/delegation (`Position`, `CellPhysics`)
- How to override a method to change/extend its behavior (`addMass`)
- How interfaces help to abstract functionality: The `AgarCell` interface hides the two cell implementations
  (`DummyAgarCell` and `MovingAgarCell`). This abstraction allows switching from a non-functional dummy implementation
  to the fully-functional `MovingAgarCell` without making any changes in the `AgarCellApp`

# Part 3: Score Board

The last increment adds some action to the game: Your player cell is challenged by enemy bots! In order to track which
cell is doing best, a score board displays all cells ranked by their mass.

You are asked to implement the `CellSorter` utility class which should sort cells by mass. Java provides
sorting out-of-the box, through the `Collections.sort` helper method. In order to make use of this method, you must
provide an implementation of the `Comparator` interface. Use `CellSorterTest` to assert that your implementation works
as expected.

Launch `AgarCellWithEnemyApp` to see your sorting logic in action!

You will learn:
- How to implement an existing interface (`Comparator`)
- How interfaces allow re-usability of complex code (`Collections.sort`)
- How to beat random enemy bots :-)