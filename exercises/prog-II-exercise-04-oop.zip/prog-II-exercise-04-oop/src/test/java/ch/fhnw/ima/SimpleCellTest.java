package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import static org.junit.Assert.assertEquals;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SimpleCellTest {

    private static final double DELTA = 0.00001;

    @Test
    public void basicConstruction() {
        SimpleCell cell = new SimpleCell("e-coli");
        assertEquals("Cell name", "e-coli", cell.getName());
        assertEquals("Cell default color", CellColor.GREEN, cell.getColor());
        assertEquals("Cell default mass", 10, cell.getMass(), DELTA);
    }

    @Test
    public void complexConstruction() {
        SimpleCell cell = new SimpleCell("test", CellColor.RED, 1000);
        assertEquals("Cell name", "test", cell.getName());
        assertEquals("Cell specific color", CellColor.RED, cell.getColor());
        assertEquals("Cell specific mass ", 1000, cell.getMass(), DELTA);
    }

    @Test
    public void radiusCalculation() {
        {
            SimpleCell cell = new SimpleCell("test");
            assertEquals("Cell radius for default mass", 1.78412, cell.calcRadius(), DELTA);
        }
        {
            SimpleCell cell = new SimpleCell("test", CellColor.MAGENTA, 31415);
            assertEquals("Cell radius for specific mass", 100, cell.calcRadius(), 0.01);
        }
    }

    @Test
    public void massMutation() {
        SimpleCell cell = new SimpleCell("test");
        cell.addMass(10);
        cell.addMass(-2);
        cell.addMass(10);
        assertEquals("Modified mass", 28, cell.getMass(), DELTA);
        cell.addMass(-100);
        assertEquals("Cell mass cannot be < 0", 0, cell.getMass(), DELTA);
        cell.addMass(99);
        assertEquals("Adding mass to zero-mass cell", 99, cell.getMass(), DELTA);
    }

}