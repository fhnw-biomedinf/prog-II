package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;
import ch.fhnw.ima.util.CellPhysics;
import ch.fhnw.ima.util.Coordinates;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AgarCellTest {

    private static final double DELTA = 0.0001;

    @Test
    public void construction() {
        AgarCell cell = createTestCell();
        assertEquals("Cell name", "caulobacter", cell.getName());
        assertEquals("Cell color", CellColor.MAGENTA, cell.getColor());
        assertEquals("Cell initial mass", 500, cell.getMass());
        assertEquals("Cell initial speed", CellPhysics.calcSpeed(cell.getMass()), cell.getSpeed(), DELTA);

        assertNotNull("Cell must have a current position", cell.getCurrentPosition());
        assertNotNull("Cell must have a target position", cell.getTargetPosition());

        assertEquals("Cell current position x-value", -99, cell.getCurrentPosition().x, DELTA);
        assertEquals("Cell current position y-value", 42, cell.getCurrentPosition().y, DELTA);

        assertEquals("Cell target position x-value", -99, cell.getTargetPosition().x, DELTA);
        assertEquals("Cell target position y-value", 42, cell.getTargetPosition().y, DELTA);
    }

    private static AgarCell createTestCell() {
        return AgarCellFactory.createCell("caulobacter", CellColor.MAGENTA, 500, new Coordinates(-99, 42));
    }

    @Test
    public void movement() {
        AgarCell cell = createTestCell();

        cell.setTargetPosition(new Coordinates(0, 0));
        assertNotNull("Cell must have a target position", cell.getTargetPosition());
        assertEquals("Cell update target position x-value", 0, cell.getTargetPosition().x, DELTA);
        assertEquals("Cell update target position y-value", 0, cell.getTargetPosition().y, DELTA);

        cell.move(3);

        assertNotNull("Cell must have a current position", cell.getCurrentPosition());
        assertEquals("Cell current position x-value after move", -71.3825, cell.getCurrentPosition().x, DELTA);
        assertEquals("Cell current position y-value after move", 30.2835, cell.getCurrentPosition().y, DELTA);
        assertEquals("Move should not influence target position x-value", 0, cell.getTargetPosition().x, DELTA);
        assertEquals("Move should not influence target position y-value", 0, cell.getTargetPosition().y, DELTA);

        cell.setTargetPosition(cell.getCurrentPosition());
        cell.move(1000);

        assertEquals("No x-value change if current eq target position", -71.3825, cell.getCurrentPosition().x, DELTA);
        assertEquals("No y-value change if current eq target position", 30.2835, cell.getCurrentPosition().y, DELTA);
    }

    @Test
    public void speedMassDependency() {
        AgarCell cell = createTestCell();
        assertEquals("Initial speed determined by initial mass", 10, cell.getSpeed(), DELTA);

        cell.addMass(1000);
        assertEquals("Cell slows down when growing", 3.0826, cell.getSpeed(), DELTA);

        cell.addMass(-500);
        assertEquals("Cell speeds up when shrinking", 4.9430, cell.getSpeed(), DELTA);

    }

}