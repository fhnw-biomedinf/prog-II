package ch.fhnw.ima.util;

import ch.fhnw.ima.AgarCell;
import ch.fhnw.ima.AgarCellFactory;
import org.junit.Test;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.toList;
import static org.junit.Assert.assertEquals;

public class CellSorterTest {

    private static final Coordinates POSITION = new Coordinates(0, 0);
    private static final Random RANDOM = new Random(42);

    @Test
    public void sort() {
        List<AgarCell> cells = createCellsWithMass0to99();
        Collections.shuffle(cells, RANDOM);

        List<AgarCell> sortedCells = CellSorter.sort(cells);

        assertEquals("Sorting should not change number of cells", 100, sortedCells.size());
        assertEquals("First cell should have mass 99 after sorting", 99, sortedCells.get(0).getMass());
        assertEquals("Last cell should have mass 0 after sorting", 0, sortedCells.get(99).getMass());
    }

    private static List<AgarCell> createCellsWithMass0to99() {
        List<Integer> zeroTo99 = IntStream.range(0, 100).mapToObj(Integer::valueOf).collect(toList());
        return zeroTo99.stream().map(CellSorterTest::createCell).collect(toList());
    }

    private static AgarCell createCell(int mass) {
        return AgarCellFactory.createCell(String.valueOf(mass), CellColor.BLACK, mass, POSITION);
    }

}