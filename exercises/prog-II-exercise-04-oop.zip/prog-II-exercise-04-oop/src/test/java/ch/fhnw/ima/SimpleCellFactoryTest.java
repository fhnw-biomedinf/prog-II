package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;
import org.junit.Test;

import java.util.List;
import java.util.Set;

import static java.util.stream.Collectors.toSet;
import static org.junit.Assert.assertEquals;

public class SimpleCellFactoryTest {

    @Test
    public void createCells() {
        List<SimpleCell> cells = SimpleCellFactory.createCells(42);

        assertEquals("Number of cells must match number of colors", CellColor.values().length, cells.size());
        Set<CellColor> usedColors = cells.stream().map(SimpleCell::getColor).collect(toSet());
        assertEquals("One cell for each color constant", CellColor.values().length, usedColors.size());

        cells.forEach(cell -> {
            assertEquals("Cell mass must be initialized from argument", 42, cell.getMass());
            assertEquals("Cell name must correspond to color constant name", cell.getName(), cell.getColor().name());
        });
    }

}