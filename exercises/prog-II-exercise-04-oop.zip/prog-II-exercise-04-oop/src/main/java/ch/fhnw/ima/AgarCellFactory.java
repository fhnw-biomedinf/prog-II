package ch.fhnw.ima;

import ch.fhnw.ima.app.part2.AgarCellApp;
import ch.fhnw.ima.util.CellColor;
import ch.fhnw.ima.util.Coordinates;

public final class AgarCellFactory {

    /**
     * Creates an {@link AgarCell}.
     *
     * @param name the name of the cell
     * @param color the color of the cell
     * @param mass the initial mass of the cell
     * @param initialPosition the initial position of the cell
     * @return the created cell
     */
    public static AgarCell createCell(String name, CellColor color, int mass, Coordinates initialPosition) {
        // TODO: Construct a MovingAgarCell once your implementation is complete
        return new DummyAgarCell(mass, initialPosition);
    }

    /**
     * A dummy implementation which assures that {@link AgarCellApp} can be launched
     * even if {@link MovingAgarCell} is not properly implemented yet. Feel free to delete this class once
     * your {@link MovingAgarCell} is fully functional!
     */
    private static class DummyAgarCell implements AgarCell {

        private final int mass;
        private final Coordinates initialPosition;

        private DummyAgarCell(int mass, Coordinates initialPosition) {
            this.mass = mass;
            this.initialPosition = initialPosition;
        }

        @Override
        public double calcRadius() {
            return 10;
        }

        @Override
        public double getSpeed() {
            return 0;
        }

        @Override
        public String getName() {
            return "MovingAgarCell not implemented yet :-(";
        }

        @Override
        public CellColor getColor() {
            return CellColor.BLACK;
        }

        @Override
        public int getMass() {
            return mass;
        }

        @Override
        public void addMass(int mass) {

        }

        @Override
        public void move(long timeDelta) {

        }

        @Override
        public Coordinates getCurrentPosition() {
            return initialPosition;
        }

        @Override
        public Coordinates getTargetPosition() {
            return initialPosition;
        }

        @Override
        public void setTargetPosition(Coordinates position) {

        }

    }

}