package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;

import java.util.Collections;
import java.util.List;

public final class SimpleCellFactory {

    /**
     * Creates one cell for each of the color constants enumerated in
     * {@link CellColor}. Cells are named according to the color constant's
     * name, e.g. "YELLOW".
     *
     * @param mass the initial mass of each cells
     * @return the list of created cells
     */
    public static List<SimpleCell> createCells(int mass) {
        // TODO: Implementation
        return Collections.emptyList();
    }

}
