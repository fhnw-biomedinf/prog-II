package ch.fhnw.ima.app.part3;

import ch.fhnw.ima.AgarCell;
import ch.fhnw.ima.AgarCellFactory;
import ch.fhnw.ima.app.ColorMapper;
import ch.fhnw.ima.util.CellColor;
import ch.fhnw.ima.util.CellSorter;
import ch.fhnw.ima.util.Coordinates;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Part 3: An actual game where your player cell is challenged by enemy bots. Demonstrates {@link CellSorter} in action.
 * <p>
 * NOTE: You do not need to change this code -> just run the application and have fun :-)
 *
 * @author Rahel Lüthy
 */
public final class AgarCellWithEnemyApp extends Application {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int DEFAULT_MASS = 800;
    private static final Random RANDOM = new Random();
    private static final int FOOD_COUNT = 10;
    private static final CellColor PLAYER_COLOR = CellColor.YELLOW;
    private static final CellColor FOOD_COLOR = CellColor.VIOLET;
    private static final CellColor ENEMY_COLOR = CellColor.RED;
    private static final int ENEMY_COUNT = 3;
    private static final double ENEMY_REDIRECT_PROBABILITY = 0.1;
    private static final double ENEMY_FOLLOW_PLAYER_PROBABILITY = 0.1;

    @Override
    public void start(Stage stage) throws Exception {
        AgarCellNode playerNode = createPlayerNode();
        List<AgarCellNode> foodNodes = createFoodNodes();
        List<AgarCellNode> enemyNodes = createEnemyNodes();
        Pane cellPane = createCellPane(playerNode, foodNodes, enemyNodes);
        Label scoreLabel = createScoreLabel();
        Label gameOverLabel = createGameOverLabel();

        AnimationTimer gameLoop = new AnimationTimer() {

            @Override
            public void handle(long now) {
                moveCells(playerNode, enemyNodes);
                List<AgarCellNode> aliveEaters = handleCollisions();
                handleGameOver(aliveEaters, playerNode, gameOverLabel);
                trackScores();
            }

            private void trackScores() {
                List<AgarCell> eatersList = eatersAsStream().map(node -> node.cell).collect(Collectors.toList());
                List<AgarCell> sortedEatersList = CellSorter.sort(eatersList);

                StringBuilder scoreBoardText = new StringBuilder();
                for (AgarCell cell : sortedEatersList) {
                    scoreBoardText.append(cell.getName()).append("\t").append(cell.getMass());
                    scoreBoardText.append("\n");
                }

                scoreLabel.setText(String.valueOf(scoreBoardText));
            }

            private List<AgarCellNode> handleCollisions() {
                Stream<AgarCellNode> aliveEaters = eatersAsStream().filter(AgarCellNode::isAlive);
                List<AgarCellNode> aliveEatersList = aliveEaters.collect(Collectors.toList());
                aliveEatersList.forEach(focusNode -> {
                    for (Node otherCell : cellPane.getChildrenUnmodifiable()) {
                        AgarCellNode otherNode = (AgarCellNode) otherCell;
                        if (!focusNode.equals(otherNode) && focusNode.getBoundsInParent().intersects(otherNode.getBoundsInParent())) {
                            AgarCellNode victim = focusNode.eatOrBeEaten(otherNode);
                            Platform.runLater(() -> cellPane.getChildren().remove(victim));
                        }
                    }
                });
                return aliveEatersList;
            }

            private Stream<AgarCellNode> eatersAsStream() {
                return Stream.concat(Stream.of(playerNode), enemyNodes.stream());
            }

        };
        gameLoop.start();

        StackPane mainView = new StackPane(cellPane, createOverlay(scoreLabel, gameOverLabel));

        Scene scene = new Scene(mainView, WIDTH, HEIGHT);
        stage.setTitle("Eat or Get Eaten");
        stage.setScene(scene);
        stage.show();
    }

    private void handleGameOver(List<AgarCellNode> aliveEaters, AgarCellNode playerNode, Label gameOverLabel) {
        if (!playerNode.isAlive()) {
            gameOverLabel.setText("GAME OVER");
        }
        if (aliveEaters.size() == 1 && aliveEaters.contains(playerNode)) {
            gameOverLabel.setText("YOU WIN");
        }
    }

    private static Label createScoreLabel() {
        Label label = new Label();
        label.setTextFill(Color.WHITE);
        return label;
    }

    private static Label createGameOverLabel() {
        Label label = new Label();
        label.setTextFill(Color.WHITE);
        label.setStyle("-fx-font-size: 50px");
        return label;
    }

    private Node createOverlay(Label scoreLabel, Label gameOverLabel) {
        FlowPane scorePane = new FlowPane(scoreLabel);
        scorePane.setPadding(new Insets(10, 10, 10, 10));

        HBox gameOverPane = new HBox(gameOverLabel);
        gameOverPane.setAlignment(Pos.CENTER);

        StackPane pane = new StackPane(scorePane, gameOverPane);
        pane.setMouseTransparent(true);
        return pane;
    }

    private static AgarCellNode createPlayerNode() {
        Coordinates initialPosition = new Coordinates(WIDTH / 2, HEIGHT / 2);
        AgarCell cell = AgarCellFactory.createCell("Player", PLAYER_COLOR, DEFAULT_MASS, initialPosition);
        return new AgarCellNode(cell);
    }

    private static List<AgarCellNode> createFoodNodes() {
        return createRandomlyPositionedCells(FOOD_COUNT, FOOD_COLOR, index -> "", DEFAULT_MASS);
    }

    private static List<AgarCellNode> createEnemyNodes() {
        Function<Integer, String> namer = index -> "Bot " + (index + 1);
        return createRandomlyPositionedCells(ENEMY_COUNT, ENEMY_COLOR, namer, DEFAULT_MASS * 2);
    }

    private static List<AgarCellNode> createRandomlyPositionedCells(int count, CellColor color, Function<Integer, String> namer, int mass) {
        return IntStream.range(0, count).mapToObj(i -> {
                    Coordinates initialPosition = randomPosition();
                    String name = namer.apply(i);
                    AgarCell foodCell = AgarCellFactory.createCell(name, color, mass, initialPosition);
                    return new AgarCellNode(foodCell);
                }
        ).collect(Collectors.toList());
    }

    private static Coordinates randomPosition() {
        int randomX = RANDOM.nextInt(WIDTH);
        int randomY = RANDOM.nextInt(HEIGHT);
        return new Coordinates(randomX, randomY);
    }

    private void moveCells(AgarCellNode playerNode, List<AgarCellNode> enemyNodes) {
        playerNode.move();

        for (AgarCellNode enemyNode : enemyNodes) {
            if (RANDOM.nextDouble() < ENEMY_REDIRECT_PROBABILITY) {
                if (RANDOM.nextDouble() < ENEMY_FOLLOW_PLAYER_PROBABILITY) {
                    enemyNode.setTargetPosition(playerNode.getCurrentPosition());
                } else {
                    enemyNode.setTargetPosition(randomPosition());
                }
            }
            enemyNode.move();
        }

    }

    private static Pane createCellPane(AgarCellNode playerNode, List<AgarCellNode> foodNodes, List<AgarCellNode> enemyNodes) {
        Pane pane = new Pane();
        pane.setStyle("-fx-background-color: black");
        pane.setOnMouseMoved(e -> {
            Coordinates position = new Coordinates(e.getX(), e.getY());
            playerNode.setTargetPosition(position);
        });
        pane.getChildren().addAll(foodNodes);
        pane.getChildren().addAll(enemyNodes);
        pane.getChildren().add(playerNode);
        return pane;
    }

    private static final class AgarCellNode extends StackPane {

        private final AgarCell cell;
        private final Circle circle;

        private boolean alive = true;

        private AgarCellNode(AgarCell cell) {
            this.cell = cell;
            circle = new Circle();
            circle.setFill(ColorMapper.map(cell.getColor()));
            circle.setOpacity(0.8);

            Text text = new Text(cell.getName());
            text.setFill(Color.WHITE);

            setAlignment(Pos.CENTER);
            getChildren().addAll(circle, text);

            refresh();
        }

        private void move() {
            cell.move(1);
            refresh();
        }

        private AgarCellNode eatOrBeEaten(AgarCellNode otherNode) {
            AgarCellNode victim;
            if (cell.getMass() >= otherNode.cell.getMass()) {
                cell.addMass(otherNode.cell.getMass());
                victim = otherNode;
            } else {
                otherNode.cell.addMass(cell.getMass());
                victim = this;
            }
            refresh();
            victim.alive = false;
            return victim;
        }

        private void refresh() {
            circle.setRadius(cell.calcRadius());
            setTranslateX(cell.getCurrentPosition().x - getWidth() / 2);
            setTranslateY(cell.getCurrentPosition().y - getHeight() / 2);
        }

        private void setTargetPosition(Coordinates position) {
            cell.setTargetPosition(position);
        }

        private Coordinates getCurrentPosition() {
            return cell.getCurrentPosition();
        }

        private boolean isAlive() {
            return alive;
        }

    }

}
