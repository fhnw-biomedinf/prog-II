package ch.fhnw.ima.app.part2;

import ch.fhnw.ima.AgarCell;
import ch.fhnw.ima.AgarCellFactory;
import ch.fhnw.ima.app.ColorMapper;
import ch.fhnw.ima.util.CellColor;
import ch.fhnw.ima.util.Coordinates;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Part 2: A simple application which shows {@link AgarCell} and {@link AgarCellFactory} in action.
 * <p>
 * NOTE: You do not need to change this code -> just run the application and have fun :-)
 *
 * @author Rahel Lüthy
 */
public final class AgarCellApp extends Application {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int DEFAULT_MASS = 800;
    private static final Random RANDOM = new Random();
    private static final int FOOD_COUNT = 10;
    private static final CellColor PLAYER_COLOR = CellColor.YELLOW;
    private static final CellColor FOOD_COLOR = CellColor.VIOLET;

    @Override
    public void start(Stage stage) throws Exception {
        AgarCellNode playerNode = createPlayerNode();
        List<AgarCellNode> foodNodes = createFoodNodes();
        Pane cellPane = createCellPane(playerNode, foodNodes);

        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                playerNode.move();
                for (Node child : cellPane.getChildrenUnmodifiable()) {
                    if (child instanceof AgarCellNode && !child.equals(playerNode)) {
                        AgarCellNode foodCell = (AgarCellNode) child;
                        if (playerNode.getBoundsInParent().intersects(child.getBoundsInParent())) {
                            playerNode.eat(foodCell);
                            Platform.runLater(() -> cellPane.getChildren().remove(child));
                        }
                    }
                }
            }
        };
        gameLoop.start();


        Scene scene = new Scene(cellPane, WIDTH, HEIGHT);
        stage.setTitle(AgarCellApp.class.getSimpleName());
        stage.setScene(scene);
        stage.show();
    }

    private static AgarCellNode createPlayerNode() {
        Coordinates initialPosition = new Coordinates(WIDTH / 2, HEIGHT / 2);
        AgarCell cell = AgarCellFactory.createCell("Player", PLAYER_COLOR, DEFAULT_MASS, initialPosition);
        return new AgarCellNode(cell);
    }

    private static List<AgarCellNode> createFoodNodes() {
        return IntStream.range(0, FOOD_COUNT).mapToObj(i -> {
                    int randomX = RANDOM.nextInt(WIDTH);
                    int randomY = RANDOM.nextInt(HEIGHT);
                    Coordinates initialPosition = new Coordinates(randomX, randomY);
                    AgarCell foodCell = AgarCellFactory.createCell("", FOOD_COLOR, DEFAULT_MASS, initialPosition);
                    return new AgarCellNode(foodCell);
                }
        ).collect(Collectors.toList());
    }

    private static Pane createCellPane(AgarCellNode playerNode, List<AgarCellNode> foodNodes) {
        Pane pane = new Pane();
        pane.setStyle("-fx-background-color: black");
        pane.setOnMouseMoved(playerNode::setTargetPosition);
        pane.getChildren().addAll(foodNodes);
        pane.getChildren().add(playerNode);
        return pane;
    }

    private static final class AgarCellNode extends StackPane {

        private final AgarCell cell;
        private final Circle circle;

        private AgarCellNode(AgarCell cell) {
            this.cell = cell;
            circle = new Circle();
            circle.setFill(ColorMapper.map(cell.getColor()));
            circle.setOpacity(0.8);

            Text text = new Text(cell.getName());
            text.setFill(Color.WHITE);

            setAlignment(Pos.CENTER);
            getChildren().addAll(circle, text);

            refresh();
        }

        private void move() {
            cell.move(1);
            refresh();
        }

        private void eat(AgarCellNode foodNode) {
            cell.addMass(foodNode.cell.getMass());
            refresh();
        }

        private void refresh() {
            circle.setRadius(cell.calcRadius());
            setTranslateX(cell.getCurrentPosition().x - getWidth() / 2);
            setTranslateY(cell.getCurrentPosition().y - getHeight() / 2);
        }

        private void setTargetPosition(MouseEvent e) {
            Coordinates position = new Coordinates(e.getX(), e.getY());
            cell.setTargetPosition(position);
        }

    }

}
