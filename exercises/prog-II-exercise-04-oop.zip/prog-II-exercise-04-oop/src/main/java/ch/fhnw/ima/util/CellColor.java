package ch.fhnw.ima.util;

public enum CellColor {

    BLACK, YELLOW, ORANGE, RED, MAGENTA, VIOLET, BLUE, CYAN, GREEN

}
