package ch.fhnw.ima.app;

import ch.fhnw.ima.util.CellColor;
import javafx.scene.paint.Color;

public final class ColorMapper {

    /**
     * Maps cell colors to the solarized palette.
     */
    public static Color map(CellColor cellColor) {
        switch (cellColor) {
            case YELLOW:
                return Color.web("#b58900");
            case ORANGE:
                return Color.web("#cb4b16");
            case RED:
                return Color.web("#dc322f");
            case MAGENTA:
                return Color.web("#d33682");
            case VIOLET:
                return Color.web("#6c71c4");
            case BLUE:
                return Color.web("#268bd2");
            case CYAN:
                return Color.web("#2aa198");
            case GREEN:
                return Color.web("#859900");
            default:
                return Color.BLACK;
        }
    }

}
