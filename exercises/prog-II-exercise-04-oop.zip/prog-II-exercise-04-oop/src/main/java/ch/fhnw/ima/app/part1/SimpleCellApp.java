package ch.fhnw.ima.app.part1;

import ch.fhnw.ima.SimpleCell;
import ch.fhnw.ima.SimpleCellFactory;
import ch.fhnw.ima.app.ColorMapper;
import javafx.application.Application;
import javafx.beans.binding.DoubleBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Part 1: A simple application which shows {@link SimpleCell} and {@link SimpleCellFactory} in action.
 * <p>
 * NOTE: You do not need to change this code -> just run the application and have fun :-)
 *
 * @author Rahel Lüthy
 */
public final class SimpleCellApp extends Application {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int DEFAULT_MASS = 400;
    private static final int MASS_INCREMENT = 200;

    @Override
    public void start(Stage stage) throws Exception {
        List<SimpleCellNode> cellNodes = createCellNodes();
        Scene scene;
        if (cellNodes.isEmpty()) {
            Text text = new Text("No cells yet :-(");
            scene = new Scene(new StackPane(text), WIDTH, HEIGHT);
        } else {
            Pane buttonPane = createButtonPane(cellNodes);
            Pane cellPane = createCellPane(cellNodes);
            Parent root = createRootPane(buttonPane, cellPane);
            scene = new Scene(root, WIDTH, HEIGHT);
        }
        stage.setTitle(SimpleCellApp.class.getSimpleName());
        stage.setScene(scene);
        stage.show();
    }

    private static Pane createButtonPane(List<SimpleCellNode> cellNodes) {
        Button decreaseButton = new Button("-");
        decreaseButton.setOnAction(event -> cellNodes.forEach(SimpleCellNode::decreaseMass));
        Button increaseButton = new Button("+");
        increaseButton.setOnAction(event -> cellNodes.forEach(SimpleCellNode::increaseMass));
        HBox box = new HBox(decreaseButton, new Text("Cell Size"), increaseButton);
        box.setSpacing(5);
        box.setPadding(new Insets(5, 5, 5, 5));
        box.setAlignment(Pos.CENTER);
        return box;
    }

    private static Pane createCellPane(List<SimpleCellNode> cellNodes) {
        Pane pane = new Pane();

        for (int i = 0; i < cellNodes.size(); i++) {
            SimpleCellNode cellNode = cellNodes.get(i);

            DoubleBinding xPositionEvenlySpaced = pane.widthProperty().divide(cellNodes.size() + 1).multiply(i + 1);
            DoubleBinding xPosition = xPositionEvenlySpaced.subtract(cellNode.widthProperty().divide(2));
            cellNode.translateXProperty().bind(xPosition);

            DoubleBinding yMiddle = pane.heightProperty().divide(2);
            DoubleBinding yPosition = yMiddle.subtract(cellNode.heightProperty().divide(2));
            cellNode.translateYProperty().bind(yPosition);
        }

        pane.getChildren().addAll(cellNodes);
        return pane;
    }

    private static VBox createRootPane(Pane buttonPane, Pane cellPane) {
        VBox box = new VBox(buttonPane, cellPane);
        box.setSpacing(5);
        VBox.setVgrow(cellPane, Priority.ALWAYS);
        return box;
    }

    private static List<SimpleCellNode> createCellNodes() {
        Stream<SimpleCell> cellStream = SimpleCellFactory.createCells(DEFAULT_MASS).stream();
        return cellStream.map(SimpleCellNode::new).collect(Collectors.toList());
    }

    private static final class SimpleCellNode extends VBox {

        private final SimpleCell cell;
        private final Circle circle;

        private SimpleCellNode(SimpleCell cell) {
            this.cell = cell;

            circle = new Circle();
            circle.setFill(ColorMapper.map(cell.getColor()));
            circle.setOpacity(0.8);
            syncRadius(cell, circle);

            Text text = new Text(cell.getName());

            setAlignment(Pos.CENTER);
            getChildren().addAll(circle, text);
        }

        private static void syncRadius(SimpleCell cell, Circle circle) {
            circle.setRadius(cell.calcRadius());
        }

        private void increaseMass() {
            cell.addMass(MASS_INCREMENT);
            syncRadius(cell, circle);
        }

        private void decreaseMass() {
            cell.addMass(-MASS_INCREMENT);
            syncRadius(cell, circle);
        }

    }

}