package ch.fhnw.ima.util;

/**
 * A helper class which can be used to calculate a cell's position and speed. Use this class when implementing the
 * {@link ch.fhnw.ima.AgarCell} interface.
 *
 * @author Rahel Lüthy
 */
public final class CellPhysics {

    private static final int FLICKER_PREVENTION_THRESHOLD = 3;
    private static final double MAX_SPEED = 10;
    private static final double MIN_SPEED = 2;
    private static final int SLOW_DOWN_RATE = 600;

    /**
     * Calculates a cell's new position based on its current physical properties.
     *
     * @param currentPosition the cell's current position
     * @param targetPosition the cell's target position (towards which it should move)
     * @param speed the cell's speed
     * @param timeDelta the time point (relative to now) for which to calculate the position
     * @return the cell's new position
     */
    public static Coordinates calcPosition(Coordinates currentPosition, Coordinates targetPosition, double speed, long timeDelta) {
        double deltaX = targetPosition.x - currentPosition.x;
        double deltaY = targetPosition.y - currentPosition.y;
        if (isCloseEnough(deltaX, deltaY)) {
            return targetPosition;
        } else {
            double angle = Math.atan2(deltaY, deltaX);

            Coordinates direction = new Coordinates(Math.cos(angle), Math.sin(angle));

            double newX = currentPosition.x + (direction.x * speed * timeDelta);
            double newY = currentPosition.y + (direction.y * speed * timeDelta);

            return new Coordinates(newX, newY);
        }
    }

    /**
     * Calculates a cell's speed based on its current mass.
     *
     * @param mass the cell's mass
     * @return the cell's speed
     */
    public static double calcSpeed(int mass) {
        return (MAX_SPEED - MIN_SPEED) * Math.exp(-mass/ SLOW_DOWN_RATE) + MIN_SPEED;
    }

    private static boolean isCloseEnough(double deltaX, double deltaY) {
        return Math.abs(deltaX * deltaX + deltaY * deltaY) < FLICKER_PREVENTION_THRESHOLD;
    }

}
