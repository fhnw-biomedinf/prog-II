package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;

/**
 * A named, colored, circular organism. A cell has a mutable mass which determines its radius.
 */
public class SimpleCell {

    /**
     * Creates a cell with default color {@link CellColor#GREEN} and default mass 10.
     *
     * @param name the cell's name
     */
    public SimpleCell(String name) {
        throw new UnsupportedOperationException();
    }

    /**
     * Creates a cell with the given properties.
     *
     * @param name the cell's name
     * @param color the cell's color
     * @param mass the cell's mass
     */
    public SimpleCell(String name, CellColor color, int mass) {
        throw new UnsupportedOperationException();
    }

    public String getName() {
        throw new UnsupportedOperationException();
    }

    public CellColor getColor() {
        throw new UnsupportedOperationException();
    }

    public int getMass() {
        throw new UnsupportedOperationException();
    }

    /**
     * Mutates this cell's mass by the given delta. The mass will never get smaller than 0.
     *
     * @param massDelta a (potentially negative) mass delta
     */
    public void addMass(int massDelta) {
        // HINT: Use Math.max to prevent negative values
        throw new UnsupportedOperationException();
    }

    /**
     * Calculates this cell's radius from its mass (r * r * Math.PI).
     *
     * @return the cell's radius
     */
    public double calcRadius() {
        // HINT: Use Math.sqrt and Math.PI
        throw new UnsupportedOperationException();
    }

}
