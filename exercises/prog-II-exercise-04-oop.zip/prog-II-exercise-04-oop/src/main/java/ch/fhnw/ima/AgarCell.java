package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;
import ch.fhnw.ima.util.Coordinates;

/**
 * Defines the properties and behavior of an agar cell.
 */
public interface AgarCell {

    String getName();

    CellColor getColor();

    int getMass();

    void addMass(int mass);

    double calcRadius();

    double getSpeed();

    void move(long timeDelta);

    Coordinates getCurrentPosition();

    Coordinates getTargetPosition();

    void setTargetPosition(Coordinates position);

}