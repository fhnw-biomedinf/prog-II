package ch.fhnw.ima.util;

public final class Coordinates {

    public final double x;
    public final double y;

    public Coordinates(double x, double y) {
        this.x = x;
        this.y = y;
    }

}
