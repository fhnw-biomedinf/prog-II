package ch.fhnw.ima;

import ch.fhnw.ima.util.CellColor;
import ch.fhnw.ima.util.Coordinates;

/**
 * A specific implementation of the {@link AgarCell} interface. Uses {@link ch.fhnw.ima.util.CellPhysics} for actual
 * position and speed calculations.
 */
public final class MovingAgarCell {

    public MovingAgarCell(String name, CellColor color, int mass, Coordinates initialPosition) {
        // TODO Implementation
    }

}
