package ch.fhnw.ima.util;

import ch.fhnw.ima.AgarCell;

import java.util.List;

/**
 * This class is used to rank cells on a score board.
 */
public final class CellSorter {

    /**
     * Sorts the given cells by their mass (highest first).
     *
     * @param cells to be sorted
     * @return the sorted cells
     */
    public static List<AgarCell> sort(List<AgarCell> cells) {
        // TODO: Use Collections.sort to sort cells by mass
        return cells;
    }

}
